﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SIW_ALLS
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Caesar_Click(object sender, RoutedEventArgs e)
        {
            Caesar caes = new Caesar();
            caes.Show();
        }

        private void Caesar1_Click(object sender, RoutedEventArgs e)
        {
            Caesar1 caes = new Caesar1();
            caes.Show();
        }

        private void XOR_Click(object sender, RoutedEventArgs e)
        {
            XOR xor = new XOR();
            xor.Show();
        }

        private void Vigenere_Click(object sender, RoutedEventArgs e)
        {
            Vigenere vig = new Vigenere();
            vig.Show();
        }

        private void Hills_Click(object sender, RoutedEventArgs e)
        {
            Hill hill = new Hill();
            hill.Show();
        }

        private void RSA_Click(object sender, RoutedEventArgs e)
        {
            RSA rsa = new RSA();
            rsa.Show();
        }

        private void AES_Click(object sender, RoutedEventArgs e)
        {
            AES aes = new SIW_ALLS.AES();
            aes.Show();
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            RC4 rc4 = new RC4();
            rc4.Show();
        }

        private void Simple_transposition_Click(object sender, RoutedEventArgs e)
        {
            SimpleTransposition st = new SimpleTransposition();
            st.Show();
        }

        private void Columnar_Click(object sender, RoutedEventArgs e)
        {
            Columnar col = new Columnar();
            col.Show();
        }
    }
}
