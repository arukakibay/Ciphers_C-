﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SIW_ALLS
{
    interface XORin
    {
        string xorIt(string key, string input);
        string xorIt1(string key, string input);
        string Decrypt(string input, string key);
    }
}
