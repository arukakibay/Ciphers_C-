﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SIW_ALLS
{
    class SimpleKey
    {
        private int[] key;
        private int size;
        bool isExtend = true;

        public SimpleKey(int size)
        {
            this.size = size;
            key = new int[size];
            for (int i = 0; i < size; i++)
            {
                key[i] = i;
            }
        }

        public void increment()
        {
            add();
        }

        public bool isExtendable()
        {
            if (!isExtend)
                return isExtend;
            if (key.Length == 1)
            {
                return false;
            }
            if (key[0] < size)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private bool isIdentity()
        {
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    if (key[i] == key[j] && i != j)
                    {
                        return false;
                    }
                }
            }
            return true;
        }

        private void add()
        {
            for (int i = size - 1; i >= 0; i--)
            {
                key[i]++;
                if (key[i] == size)
                {
                    key[i] = 0;
                    if (i == 0)
                    {
                        isExtend = false;
                    }
                    continue;
                }
                else if (!isIdentity())
                {
                    add();
                    break;
                }
                else
                {
                    break;
                }
            }
        }

        public string toString()
        {
            StringBuilder sb = new StringBuilder();
            foreach (int i in key)
            {
                sb.Append(Convert.ToInt32(i));
            }
            return sb.ToString();
        }
    }
}
