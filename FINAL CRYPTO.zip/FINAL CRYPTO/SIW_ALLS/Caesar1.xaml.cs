﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SIW_ALLS
{
    /// <summary>
    /// Interaction logic for Caesar1.xaml
    /// </summary>
    public partial class Caesar1 : Window
    {
        public Caesar1()
        {
            InitializeComponent();
        }
        CaesarF caesar = new CaesarRus();
        private int wrong = 0;
        private void Go_Click(object sender, RoutedEventArgs e)
        {

            if ((bool)Encrypt.IsChecked)
            {
                Output.Text = caesar.encrypt(Input.Text, Key.Text);
            }
            else
            {
                string result;
                string key = Key.Text;
                do
                {
                    if (Key.Text == "")
                    {
                        key = caesar.analisys(Input.Text, wrong);
                        wrong++;
                    }
                    result = caesar.decrypt(Input.Text, key);
                } while (!caesar.checkAnswer(result));
                Output.Text = result;
                Key.Text = key;
            }
        }

        private void Clean_Click(object sender, RoutedEventArgs e)
        {
            Output.Text = "";
            Input.Text = "";
        }

        private void ChangeLanguage(object sender, SelectionChangedEventArgs e)
        {
            if (comboBox.SelectedIndex == 0)
            {
                caesar = new CaesarRus();
            }
            else
            {
                caesar = new CaesarEng();
            }
        }

        private void Encrypt_Checked(object sender, RoutedEventArgs e)
        {

        }
        private void Wrong(object sender, TextChangedEventArgs e)
        {
            wrong = 0;
        }
    }
}
