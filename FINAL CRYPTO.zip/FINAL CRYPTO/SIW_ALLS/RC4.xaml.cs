﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SIW_ALLS
{
    /// <summary>
    /// Interaction logic for RC4.xaml
    /// </summary>
    public partial class RC4 : Window
    {
        public RC4()
        {
            InitializeComponent();
        }
        RCfour rc4 = new RCfourEng();
        private int wrong = 0;
        private void Go_Click(object sender, RoutedEventArgs e)
        {
            if ((bool)Encrypt.IsChecked)
            {
                Output.Text = rc4.EncrDecr(Input.Text, Key.Text);
            }
            else if ((bool)Decrypt.IsChecked)
            {
                Input.Text = rc4.EncrDecr(Output.Text, Key.Text);
            }

        }

        private void Clean_Click(object sender, RoutedEventArgs e)
        {
            
            Input.Text = "";
        }
    }
}
