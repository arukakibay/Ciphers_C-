﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SIW_ALLS
{
    /// <summary>
    /// Interaction logic for Columnar.xaml
    /// </summary>
    public partial class Columnar : Window
    {
        public Columnar()
        {
            InitializeComponent();
        }
        Encryptor encryptor = new Encryptor();
        KeyGenerator generator = new KeyGenerator();
        private void Encrypt_Click(object sender, RoutedEventArgs e)
        {
            Output.Text = encryptor.encryptColumnar(Input.Text, KeyField.Text);
        }

        private void Decrypt_Click(object sender, RoutedEventArgs e)
        {
            Output.Text = encryptor.decryptColumnar(Input.Text, KeyField.Text);
        }

        private void Generate_key_Click(object sender, RoutedEventArgs e)
        {
            KeyField.Text = generator.generateColumnar(KeyLength.SelectedIndex);
        }
    }
}
