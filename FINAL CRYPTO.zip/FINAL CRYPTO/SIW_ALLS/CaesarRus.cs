﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SIW_ALLS
{
    class CaesarRus : CaesarF
    {

        private int newLetter(char c, int key)
        {
            int c_index = (int)c;
            int cc_index = 0;
            if (c_index >= 1072 && c_index <= 1103)
            {
                if (c_index + key <= 1103 && c_index + key >= 1072)
                    cc_index = c_index + key;
                else if (c_index + key > 1103)
                    cc_index = 1072 - 1 + c_index + key - 1103;
                else if (c_index + key < 1073)
                    cc_index = 1103 - (1072 - 1 - (c_index + key));
            }
            else
                cc_index = c_index;
            return cc_index;
        }

        public string encrypt(string plainText, string keyStr)
        {
            string cipher;
            int key = int.Parse(keyStr);
            key = key % 32;

            char[] ch = new char[plainText.Count()];

            // removing spaces
            /*for (int i = 0; i < plainText.Count(); i++)
				if (plainText[i] == ' ')
				{
					plainText = plainText.Remove(i, 1);
					i--;
				}
*/

            // to lowercase
            plainText = plainText.ToLower();

            //// removing others
            //for (int i = 0; i < plainText.Count(); i++)
            //    if (plainText[i] < 97 || plainText[i] > 122)
            //    {
            //        plainText = plainText.Remove(i, 1);
            //        i--;
            //    }

            for (int i = 0; i < plainText.Count(); i++)
            {
                ch[i] = (char)newLetter(plainText[i], key);
            }
            cipher = new string(ch);
            return cipher;
        }

        public string decrypt(string cipher, string keyStr)
        {
            string plainText;

            int key = -int.Parse(keyStr);
            key = key % 32;
            char[] ch = new char[cipher.Count()];

            for (int i = 0; i < cipher.Count(); i++)
                ch[i] = (char)newLetter(cipher[i], key);

            plainText = new string(ch);

            return plainText;
        }

        public string analisys(string plainText, int wrong)
        {
            string most = "оеаинтср";
            Dictionary<char, int> letters = new Dictionary<char, int>();

            foreach (char i in plainText)
            {
                if (i == ' ')
                {
                    continue;
                }
                if (letters.ContainsKey(i))
                {
                    letters[i]++;
                }
                else
                {
                    letters.Add(i, 1);
                }
            }

            var keyOfMaxValue = letters.Aggregate((x, y) => x.Value > y.Value ? x : y).Key;
            int key = Math.Abs(keyOfMaxValue - most[wrong]);
            string strKey = Convert.ToString(key);
            return strKey;
        }

        public bool checkAnswer(string answer)
        {
            string[] russionnotbi = { "aъ", "aь", "бй", "бф", "гщ", "гъ", "еъ", "еь", "жй", "жц", "жщ", "жъ", "жы", "йъ", "къ", "лъ", "мъ", "оъ", "пъ", "ръ", "уъ",
                                      "уь", "фщ", "фъ", "хы", "хь", "цщ", "цъ", "цю", "чф", "чц", "чщ", "чъ", "чы", "чю", "шщ", "шъ", "шы", "шю", "щг", "щж", "щл",
                                      "щх", "щц", "щч", "щш", "щъ", "щы", "щю", "щя", "ъа", "ъб", "ъг", "ъд", "ъз", "ъй", "ък", "ъл", "ън", "ъо", "ъп", "ър", "ъс",
                                      "ът", "ъу", "ъф", "ъх", "ъц", "ъч", "ъш", "ъщ", "ъъ", "ъы", "ъь", "ъэ", "ыъ", "ыь", "ьъ", "ьы", "эа", "эж", "эи", "эо", "эу",
                                      "эщ", "эъ", "эы", "эь", "эю", "эя", "юъ", "юь", "яъ", "яы", "яь", "ьь" };
            foreach (string bi in russionnotbi)
            {
                if (answer.IndexOf(bi) >= 0)
                {
                    return false;
                }
            }
            return true;
        }
    }
}
