﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SIW_ALLS
{
    interface RCfour
    {
        string EncrDecr(string input, string key);
       // string Decryption_by_brute_force(string encrypted, string key, string plaintext);
    }
}
