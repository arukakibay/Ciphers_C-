﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SIW_ALLS
{
    class CaesarEng : CaesarF
    {
        private int newLetter(char c, int key)
        {
            int c_index = (int)c;
            int cc_index = 0;
            if (c_index >= 97 && c_index <= 122)
            {
                if (c_index + key <= 122 && c_index + key >= 97)
                    cc_index = c_index + key;
                else if (c_index + key > 122)
                    cc_index = 97 - 1 + c_index + key - 122;
                else if (c_index + key < 1073)
                    cc_index = 122 - (97 - 1 - (c_index + key));
            }
            else
                cc_index = c_index;
            return cc_index;
        }

        public string encrypt(string plainText, string keyStr)
        {
            string cipher;
            int key = int.Parse(keyStr);
            key = key % 26;

            char[] ch = new char[plainText.Count()];

            // removing spaces
            /*for (int i = 0; i < plainText.Count(); i++)
				if (plainText[i] == ' ')
				{
					plainText = plainText.Remove(i, 1);
					i--;
				}
*/

            // to lowercase
            plainText = plainText.ToLower();

            //// removing others
            //for (int i = 0; i < plainText.Count(); i++)
            //    if (plainText[i] < 122 || plainText[i] > 122)
            //    {
            //        plainText = plainText.Remove(i, 1);
            //        i--;
            //    }

            for (int i = 0; i < plainText.Count(); i++)
            {
                ch[i] = (char)newLetter(plainText[i], key);
            }
            cipher = new string(ch);
            return cipher;
        }

        public string decrypt(string cipher, string keyStr)
        {
            string plainText;

            int key = -int.Parse(keyStr);
            key = key % 26;
            char[] ch = new char[cipher.Count()];

            for (int i = 0; i < cipher.Count(); i++)
                ch[i] = (char)newLetter(cipher[i], key);

            plainText = new string(ch);

            return plainText;
        }

        public string analisys(string plainText, int wrong)
        {
            string most = "etaoinsh";
            Dictionary<char, int> letters = new Dictionary<char, int>();

            foreach (char i in plainText)
            {
                if (i == ' ')
                {
                    continue;
                }
                if (letters.ContainsKey(i))
                {
                    letters[i]++;
                }
                else
                {
                    letters.Add(i, 1);
                }
            }

            var keyOfMaxValue = letters.Aggregate((x, y) => x.Value > y.Value ? x : y).Key;
            int key = Math.Abs(keyOfMaxValue - most[wrong]);
            string strKey = Convert.ToString(key);
            return strKey;
        }

        public bool checkAnswer(string answer)
        {
            string[] englishnotbi = { "bq", "bz", "cf", "cj", "cv", "cx", "fq", "fv", "fx", "fz", "gq", "gv", "gx", "hx", "hz", "jb", "jd", "jf", "jg", "jh", "jl",
                                     "jm", "jp", "jq", "jr", "js", "jt", "jv", "jw", "jx", "jy", "jz", "kq", "kx", "kz", "mx", "mz", "pq", "pv", "px", "qb", "qc",
                                     "qd", "qf", "qg", "qh", "qj", "qk", "ql", "qm", "qn", "qp", "qq", "qv", "qw", "qx", "qy", "qz", "sx", "tq", "vb", "vf", "vh",
                                     "vj", "vk", "vm", "vp", "vq", "vw", "vx", "wq", "wv", "wx", "xd", "xj", "xk", "xr", "xz", "yq", "yy", "zf", "zr", "zx" };
            foreach (string bi in englishnotbi)
            {
                if (answer.IndexOf(bi) >= 0)
                {
                    return false;
                }
            }
            return true;
        }

    }
}
