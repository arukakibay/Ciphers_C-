﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SIW_ALLS
{
    /// <summary>
    /// Interaction logic for Hill.xaml
    /// </summary>
    public partial class Hill : Window
    {
        Random rnd = new Random();

        string englishalp = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        public Hill()
        {
            InitializeComponent();
        }
        /* static void getCofactor(int[,] mat, int[,] temp, int p, int q, int n)
         {
             int i = 0, j = 0;
             for (int row = 0; row < n; row++)
             {
                 for (int col = 0; col < n; col++)
                 {
                     // Copying into temporary matrix  only those element which are not in given row and column 
                     if (row != p && col != q)
                     {
                         temp[i, j++] = mat[row, col];
                         // Row is filled, so increase row index and reset col index 
                         if (j == n - 1)
                         {
                             j = 0;
                             i++;
                         }
                     }
                 }
             }
         }
         static int determinantOfMatrix(int[,] mat, int n)
         {
             int D = 0;
             if (n == 1)
                 return mat[0, 0];
             int[,] temp = new int[n, n];
             int sign = 1;
             for (int f = 0; f < n; f++)
             {
                 getCofactor(mat, temp, 0, f, n);
                 D += sign * mat[0, f] * determinantOfMatrix(temp, n - 1);
                 sign = -sign;
             }
             return D;
         }
         static int module_det(int[,] mat, int n)
         {
             int D = determinantOfMatrix(mat, n); 
             //int D = 29;
             int w = 0;
             for (int i = 0; i < 26; i++)
             {
                 if (D < 0)
                 {
                     if (((-D) * i) % 26 == 1)
                     {
                         w = i;
                     }
                 }
                 if (D > 0)
                 {
                     if ((D * i) % 26 == 1)
                     {
                         w = i;
                     }
                 }
             }
             return w;
         }
         static string encrypt(string plaintext, int[,] kkey, int klength)
         {
             int n, n2, k = 0;
             for (int i = 0; i < plaintext.Count(); i++)
             {
                 if (plaintext[i] == ' ')
                 {
                     k++;
                 }
             }
             int b = plaintext.Length - k; //текст без пробелов
             if (b % klength == 0)
             {
                 n = plaintext.Length;
             }
             else
             {
                 n2 = klength - b % klength;
                 n = b + n2;
             }

             for (int i = 0; i < plaintext.Count(); i++)
             {
                 if (plaintext[i] == ' ')
                 {
                     plaintext = plaintext.Remove(i, 1);
                     i--;
                 }
             }

             for (int i = plaintext.Count(); i < n; i++)
             {
                 plaintext = plaintext.Insert(i, "j");
             }
             //Console.WriteLine(plaintext);
             int q = plaintext.Length / klength; // 12/3==4
             int[] mini = new int[klength];
             int[] maxi = new int[plaintext.Length];
             for (int w = 0; w < q; w++) //4
             {
                 for (int i = 0; i < klength; i++)
                 {
                     int temp = 0;
                     for (int j = 0; j < klength; j++)
                     {
                         temp += kkey[i, j] * ((int)plaintext[j + w * klength] - 'a');
                     }
                     mini[i] = temp % 26;
                     maxi[i + w * klength] = mini[i];
                     //Console.Write(maxi[i + w * klength] + "  ");
                 }
             }
             char[] charmaxi = new char[plaintext.Length];
             for (int i = 0; i < plaintext.Length; i++)
             {
                 charmaxi[i] = (char)(maxi[i] + 97);
                 //Console.Write(charmaxi[i] + " ");
             }
             string z = new string(charmaxi);
             return z;
         }
         static int[,] T(int[,] matrix, int n)
         {
             int t;
             for (int i = 0; i < n; i++)
             {
                 for (int j = i; j < n; j++)
                 {
                     t = matrix[i, j];
                     matrix[i, j] = matrix[j, i];
                     matrix[j, i] = t;
                 }
             }
             return matrix;
         }

         /*
         decryption starts
         */

        /* static string decrypt(string ciphertext, int[,] kkey, int klength)
         {
             int det = module_det(kkey, klength);//
             //transposed matrix
             kkey = T(kkey, klength); //транспонируется
             //numerical inverse matrix
             int[,] changedkey = new int[klength, klength];
             int[,] subA = new int[klength - 1, klength - 1];
             for (int i = 0; i < klength; i++)
             {
                 for (int j = 0; j < klength; j++)
                 {
                     for (int k = 0; k < klength; k++)
                     {
                         for (int l = 0; l < klength; l++)
                         {
                             if (k != i && l != j)
                             {
                                 if (k < i && l < j)
                                     subA[k, l] = kkey[k, l];
                                 if (k > i && l < j)
                                     subA[k - 1, l] = kkey[k, l];
                                 if (k > i && l > j)
                                     subA[k - 1, l - 1] = kkey[k, l];
                                 if (k < i && l > j)
                                     subA[k, l - 1] = kkey[k, l];

                             }
                         }
                     }
                     changedkey[i, j] = determinantOfMatrix(subA, klength - 1);
                 }
             }
             for (int i = 0; i < klength; i++)//final inverse matrix
             {
                 for (int j = 0; j < klength; j++)
                 {
                     int x = (Convert.ToInt32(Math.Pow(-1, i + j)) * changedkey[i, j]) * det;//Key
                     if (x > 0)
                     {
                         changedkey[i, j] = (1) * x % 26;
                     }
                     else
                     {
                         changedkey[i, j] = 26 - x % 26;
                     }

                 }
             }
             //multiplication of inverse to ciphertext
             int q = ciphertext.Length / klength; // 12/3=4
             int[] mini = new int[klength];
             int[] maxi = new int[ciphertext.Length];
             for (int w = 0; w < q; w++) //4
             {
                 for (int i = 0; i < klength; i++)
                 {
                     int temp = 0;
                     for (int j = 0; j < klength; j++)
                     {
                         temp += changedkey[i, j] * ((int)ciphertext[j + w * klength]);
                     }
                     mini[i] = temp % 26;
                     maxi[i + w * klength] = mini[i];

                 }
             }
             //answer in letters
             char[] charmaxi = new char[ciphertext.Length];
             for (int i = 0; i < ciphertext.Length; i++)
             {
                 charmaxi[i] = (char)((maxi[i] + 97));

             }
             string z = new string(charmaxi);
             return z;
         }
         private void Start_Click(object sender, RoutedEventArgs e)
         {
             string key1 = key.Text;
             int k = key1.Length;
             int klength = (int)Math.Sqrt((double)k);
             for (int i = 0; i < key1.Length; i++)
             {
                 if (key1[i] == ' ')
                 {
                     key1 = key1.Remove(i, 1);
                     i--;
                 }
             }

             int[,] kkey = new int[klength, klength];
             for (int i = 0; i < klength; i++)
             {
                 for (int j = 0; j < klength; j++)
                 {
                     kkey[i, j] = (int)char.ToLower(key1[j + i * klength]) - 'a';
                 }
             }


             string plaintext = text.Text;
             for (int i = 0; i < plaintext.Length; i++)
             {
                 if (plaintext[i] == ' ')
                 {
                     plaintext = plaintext.Remove(i, 1);
                     i--;
                 }
             }
             enc.Text = encrypt(plaintext, kkey, klength);
             dec.Text = decrypt(plaintext, kkey, klength);*/
        void getCofactor(int[,] A, int[,] temp, int p, int q, int n)
        {
            int i = 0, j = 0;
            for (int row = 0; row < n; row++)
            {
                for (int col = 0; col < n; col++)
                {
                    if (row != p && col != q)
                    {
                        temp[i, j++] = A[row, col];
                        if (j == n - 1)
                        {
                            j = 0;
                            i++;
                        }
                    }
                }
            }
        }

        int determinant(int[,] A, int n, int N)
        {
            int D = 0;
            if (n == 1)
                return A[0, 0];
            int[,] temp = new int[N, N];
            int sign = 1;
            for (int f = 0; f < n; f++)
            {
                getCofactor(A, temp, 0, f, n);
                D += sign * A[0, f] * determinant(temp, n - 1, N);
                sign = -sign;
            }
            return D;
        }

        int[,] adjoint(int[,] A, int N, string alp)
        {
            int sign = -1;
            int[,] temp = new int[N, N];
            int[,] adj = new int[N, N];
            for (int i = 0; i < N; i++)
            {
                for (int j = 0; j < N; j++)
                {
                    getCofactor(A, temp, i, j, N);
                    adj[j, i] = Convert.ToInt32(Math.Pow(sign, i + j)) * (determinant(temp, N - 1, N - 1));
                    adj[j, i] = mod(adj[j, i], alp.Length);
                }
            }
            return adj;
        }

        static string multiple(int[] a, int[,] key, string alp)
        {
            string result = "";
            int sum = 0;
            for (int i = 0; i < a.Length; i++)
            {
                sum = 0;
                for (int j = 0; j < a.Length; j++)
                {
                    sum += a[j] * key[i, j];
                }
                sum = sum % alp.Length;
                result += alp[sum];
            }
            return result;
        }

        static int[] index(string a, string alp)
        {
            int[] index = new int[a.Length];
            for (int j = 0; j < a.Length; j++)
            {
                for (int i = 0; i < alp.Length; i++)
                {
                    if (alp[i] == a[j])
                    {
                        index[j] = i;
                    }

                }
            }
            return index;
        }

        static int mod(int a, int n)
        {
            int result = 0;
            if (a < 0)
            {
                result = n + (a % n);
            }
            else
            {
                result = a % n;
            }
            return result;
        }
        int x = -1;
        private void Start_Click(object sender, RoutedEventArgs e)
        {
            string s = text.Text.ToUpper(), alp;
            s = s.Replace(" ", string.Empty);
            int length = 9, det; int size = Convert.ToInt32(Math.Sqrt(length));
            while (s.Length % size != 0)
            {
                s += " ";
            }


            alp = englishalp;



            int[,] keyarray = new int[size, size];
            string keys;
            do
            {
                keys = ""; x = -1;
                for (int i = 0; i < size; i++)
                {
                    for (int j = 0; j < size; j++)
                    {
                        keyarray[i, j] = rnd.Next(alp.Length);
                        keys += alp[keyarray[i, j]];
                    }
                }
                int a = mod(determinant(keyarray, size, size), alp.Length);
                det = determinant(keyarray, size, size);
                for (int i = 1; i < alp.Length; i++)
                {
                    if (mod(a * i, alp.Length) == 1)
                    {
                        x = i;
                        break;
                    }
                }
            } while (det == 0 || x == -1);

            int[] indexs = index(s, alp);
            int[] sblock = new int[size];
            int count = 0;
            string result = "";
            for (int i = 0; i < s.Length / size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    sblock[j] = indexs[count];
                    count++;
                }
                result += multiple(sblock, keyarray, alp);
            }
            enc.Text = result;
            key.Text = keys;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string alp;

            alp = englishalp;

            int[] keyindex = index(key.Text, alp);
            int size = Convert.ToInt32(Math.Sqrt(keyindex.Length)), count = 0;
            int[,] keyarray = new int[size, size];
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    keyarray[i, j] = keyindex[count];
                    count++;
                }
            }

            int a = mod(determinant(keyarray, size, size), alp.Length);
            int x = -1;
            for (int i = 1; i < alp.Length; i++)
            {
                if (mod(a * i, alp.Length) == 1)
                {
                    x = i;
                    break;
                }
            }

            //MessageBox.Show(determinant(keyarray, size, size) + " " + a+" "+x, "");

            int[,] adj = adjoint(keyarray, size, alp);

            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    adj[i, j] = mod(x * adj[i, j], alp.Length);
                }
            }

            string s = enc.Text;
            s = s.Replace(" ", string.Empty);
            int[] indexs = index(s, alp);
            int[] sblock = new int[size];
            string result = "";
            count = 0;
            for (int i = 0; i < s.Length / size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    sblock[j] = indexs[count];
                    count++;
                }
                result += multiple(sblock, adj, alp);
            }
            dec.Text = result;
        }
    }
    }

