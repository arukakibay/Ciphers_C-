﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace SIW_ALLS
{
    class VigenereF:Vigenerein
    {

        private const char LowerBound = 'A';
        private const char UpperBound = 'Z';
        private const int AlphabetSize = UpperBound - LowerBound + 1;
        /*
        private int newLetter(char c, int key)
		{
			int c_index = (int)c;
			int cc_index = 0;
			if (c_index >= 1072 && c_index <= 1103)
			{
				if (c_index + key <= 1103 && c_index + key >= 1072)
					cc_index = c_index + key;
				else if (c_index + key > 1103)
					cc_index = 1072 - 1 + c_index + key - 1103;
				else if (c_index + key < 1073)
					cc_index = 1103 - (1072 - 1 - (c_index + key));
			}
			else
				cc_index = c_index;
			return cc_index;
		}*/

        public string encrypt(string plaintext, string key)
        {
            //string cipher;
            //int key = int.Parse(keyStr);
            ///string key = key % 32;
            plaintext = PrepareInput(plaintext);
            key = PrepareInput(key);
            var ciphertext = new StringBuilder();
            for (var i = 0; i < plaintext.Length; i++)
            {
                var offset = key[i % key.Length] - LowerBound + 1;
                var encrypted = plaintext[i] + offset;
                if (encrypted > UpperBound)
                {
                    encrypted -= AlphabetSize;
                }

                ciphertext.Append((char)encrypted);
            }

            return ciphertext.ToString();
            ///char[] ch = new char[plainText.Count()];

            // to lowercase
            //plainText = plainText.ToLower();

            /*
                for (int i = 0; i < plainText.Count(); i++)
                {
                    ch[i] = (char)newLetter(plainText[i], key);
                }
                cipher = new string(ch);
                return cipher;*/

        }

        public string decrypt(string ciphertext, string key)
        {
            /*string plainText;

			int key = -int.Parse(keyStr);
			key = key % 32;
			char[] ch = new char[cipher.Count()];

			for (int i = 0; i < cipher.Count(); i++)
				ch[i] = (char)newLetter(cipher[i], key);

			plainText = new string(ch);

			return plainText;*/
            ciphertext = PrepareInput(ciphertext);
            key = PrepareInput(key);

            var plaintext = new StringBuilder();
            for (var i = 0; i < ciphertext.Length; i++)
            {
                var offset = key[i % key.Length] - LowerBound + 1;
                var decrypted = ciphertext[i] - offset;
                if (decrypted < LowerBound)
                {
                    decrypted += AlphabetSize;
                }

                plaintext.Append((char)decrypted);
            }

            return plaintext.ToString();
        }

        public string analisys(string plainText, int wrong)
        {
            string most = "etaoinsh";
            Dictionary<char, int> letters = new Dictionary<char, int>();

            foreach (char i in plainText)
            {
                if (i == ' ')
                {
                    continue;
                }
                if (letters.ContainsKey(i))
                {
                    letters[i]++;
                }
                else
                {
                    letters.Add(i, 1);
                }
            }

            var keyOfMaxValue = letters.Aggregate((x, y) => x.Value > y.Value ? x : y).Key;
            int key = Math.Abs(keyOfMaxValue - most[wrong]);
            string strKey = Convert.ToString(key);
            return strKey;
        }
        public bool checkAnswer(string answer)
        {
            string[] russionnotbi = { "bq", "bz", "cf", "cj", "cv", "cx", "fq", "fv", "fx", "fz", "gq", "gv", "gx", "hx", "hz", "jb", "jd", "jf", "jg", "jh", "jl",
                                     "jm", "jp", "jq", "jr", "js", "jt", "jv", "jw", "jx", "jy", "jz", "kq", "kx", "kz", "mx", "mz", "pq", "pv", "px", "qb", "qc",
                                     "qd", "qf", "qg", "qh", "qj", "qk", "ql", "qm", "qn", "qp", "qq", "qv", "qw", "qx", "qy", "qz", "sx", "tq", "vb", "vf", "vh",
                                     "vj", "vk", "vm", "vp", "vq", "vw", "vx", "wq", "wv", "wx", "xd", "xj", "xk", "xr", "xz", "yq", "yy", "zf", "zr", "zx" };
            foreach (string bi in russionnotbi)
            {
                if (answer.IndexOf(bi) >= 0)
                {
                    return false;
                }
            }
            return true;
        }
        public List<string> Crack(string ciphertext)
        {
            var sequenceSpacings = IdentifySequenceSpacings(ciphertext);
            var factors = GetFactors(sequenceSpacings);

            return GenerateLikelyKeys(ciphertext, factors);
        }

        private static string PrepareInput(string input)
        {
            var regex = new Regex("[^A-Z]");
            return regex.Replace(input.ToUpper(), string.Empty);
        }

        private IEnumerable<int> IdentifySequenceSpacings(string ciphertext)
        {
            var sequenceSpacings = new List<int>();
            for (var i = 0; i + 3 < ciphertext.Length; i++)
            {
                var sequence = ciphertext.Substring(i, 3);
                for (var j = i + 1; j + 3 < ciphertext.Length; j++)
                {
                    if (sequence == ciphertext.Substring(j, 3))
                    {
                        sequenceSpacings.Add(j - i);
                    }
                }
            }

            return sequenceSpacings.Distinct();
        }

        private static IEnumerable<int> GetFactors(IEnumerable<int> numbers)
        {
            var factors = new List<int>();
            foreach (var number in numbers)
            {
                var max = (int)Math.Sqrt(number);
                for (var factor = 1; factor <= max; factor++)
                {
                    if (number % factor == 0)
                    {
                        factors.Add(factor);
                        factors.Add(number / factor);
                    }
                }
            }

            factors.RemoveAll(f => f == 1);

            if (!factors.Any())
            {
                return new List<int>();
            }

            var groupedFactors = factors.GroupBy(f => f).ToList();
            var mostOccurrences = groupedFactors.Max(g => g.Count());
            return groupedFactors.Where(g => g.Count() == mostOccurrences).Select(g => g.Key);
        }

        private List<string> GenerateLikelyKeys(string ciphertext, IEnumerable<int> factors)
        {
            var keys = new List<string>();
            foreach (var factor in factors)
            {
                var substrings = GenerateSubstrings(ciphertext, factor);
                var likelySubkeys = GenerateLikelySubkeys(substrings);

                var possibleKeys = new List<string>();
                BuildKeys(possibleKeys, likelySubkeys, new char[factor], 0);

                keys.AddRange(possibleKeys);
            }

            return keys;
        }

        private static IEnumerable<string> GenerateSubstrings(string ciphertext, int factor)
        {
            for (var i = 0; i < factor; i++)
            {
                var substring = new StringBuilder();
                for (var j = i; j < ciphertext.Length; j += factor)
                {
                    substring.Append(ciphertext[j]);
                }

                yield return substring.ToString();
            }
        }

        private List<List<string>> GenerateLikelySubkeys(IEnumerable<string> substrings)
        {
            var likelySubkeys = new List<List<string>>();
            foreach (var substring in substrings)
            {
                var scores = new Dictionary<string, int>();
                for (var subkey = LowerBound; subkey <= UpperBound; subkey++)
                {
                    var plaintext = decrypt(substring, subkey.ToString());
                    var score = AnalyzeLetterFrequency(plaintext);

                    scores.Add(subkey.ToString(), score);
                }

                var highestScore = scores.Values.Max();
                var likelySubkey = scores.Where(s => s.Value == highestScore).Select(s => s.Key).ToList();
                likelySubkeys.Add(likelySubkey);
            }

            return likelySubkeys;
        }

        private static int AnalyzeLetterFrequency(string text)
        {
            //very basic scoring method, scores for each occurrence of one of the 3 most frequent letters in english
            //from wikipedia, letters ordered by frequency from highest to lowest are: ETAOINSHRDLCUMWFGYPBVKJXQZ
            return text.Count(l => "ETA".Contains(l));
        }

        private void BuildKeys(ICollection<string> keys, IReadOnlyList<List<string>> subkeys, char[] builder, int index)
        {
            if (index == subkeys.Count)
            {
                keys.Add(new string(builder));
                return;
            }

            for (var i = 0; i < subkeys[index].Count; i++)
            {
                builder[index] = subkeys[index][i][0];
                BuildKeys(keys, subkeys, builder, index + 1);
            }
        }
    }
}
