﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SIW_ALLS
{
    interface CaesarF
    {
        string encrypt(string plainText, string keyStr);
        string decrypt(string plainText, string keyStr);
        string analisys(string plainText, int wrong);
        bool checkAnswer(string answer);
    }
}
