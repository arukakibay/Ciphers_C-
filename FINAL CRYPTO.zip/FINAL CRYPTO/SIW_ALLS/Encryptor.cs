﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SIW_ALLS
{
    class Encryptor
    {
        public string encryptRSA(string plainText, string strKey)
        {
            RSAhelper rsa = new RSAhelper();
            int e = Convert.ToInt32(strKey
                .Substring(0, strKey.IndexOf(','))
                );

            int n = Convert.ToInt32(strKey
                .Substring(strKey.IndexOf(',') + 1)
                );

            int[] res = rsa.encrypt(plainText, e, n);
            string cipher = "";
            for (int i = 0; i < res.Length; i++)
            {
                if (i == res.Length - 1)
                {
                    cipher += res[i];
                    break;
                }
                cipher += res[i] + " ";
            }
            return cipher;
        }

        public string decryptRSA(string cipherText, string strKey)
        {
            RSAhelper rsa = new RSAhelper();
            int d = Convert.ToInt32(strKey
                .Substring(0, strKey.IndexOf(','))
                );

            int n = Convert.ToInt32(strKey
                .Substring(strKey.IndexOf(',') + 1)
                );

            string[] cipherStr = cipherText.Split(' ');
            int[] cipher = new int[cipherStr.Length];

            for (int i = 0; i < cipherStr.Length; i++)
            {
                try
                {
                    cipher[i] = Convert.ToInt32(cipherStr[i]);
                }
                catch (Exception e)
                {
                    cipher[i] = 100;
                }
            }

            return rsa.decrypt(cipher, d, n);
        }
        public string encryptAES(string plainText, string key)
        {
            
            AEShelper aes = new AEShelper();
            return aes.encrypt(key, plainText);
        }

        bool IsDigitsOnly(string str)
        {
            foreach (char c in str)
            {
                if (c < '0' || c > '9')
                    if (c != ' ')
                        return false;
            }

            return true;
        }

        public int[] keyConverter(string strKey)
        {
            string[] ckey = strKey.Split(' ');
            int[] key = new int[ckey.Length];
            for (int i = 0; i < ckey.Length; i++)
            {
                key[i] = Convert.ToInt32(ckey[i]);
            }
            return key;
        }

        public bool key_validator(string strKey, int textLength)
        {
            if (IsDigitsOnly(strKey))
            {
                int[] key = keyConverter(strKey);
                bool valid = false;
                if (key.Count() > textLength)
                    return false;
                if (key.Length != key.Distinct().Count())
                    return false;
                for (int i = 0; i < key.Count(); i++)
                {
                    if (key[i] >= 0 && key[i] < key.Count())
                        valid = true;
                    else
                        return false;
                }
                return valid;
            }
            return false;
        }
        public string encryptSimple(string plainText, string strKey)
        {
            if (key_validator(strKey, plainText.Count()))
            {
                int[] key = keyConverter(strKey);
                SimpleTransposition1 simple = new SimpleTransposition1();
                return simple.encrypt(plainText, key);
            }
            else
            {
                return "Invalid key or plaintext!";
            }

        }
        public string decryptSimple(string plainText, string strKey)
        {
            if (key_validator(strKey, plainText.Count()))
            {
                int[] key = keyConverter(strKey);
                SimpleTransposition1 simple = new SimpleTransposition1();
                //if (strKey == "" || strKey == null) return simple.superDecrypt(plainText);
                return simple.decrypt(plainText, key);
            }
            else
            {
                return "Invalid key or cipher!";
            }

        }
  

        public string encryptColumnar(string plainText, string strKey)
        {
            if (key_validator(strKey, plainText.Count()))
            {
                int[] key = keyConverter(strKey);
                ColumnarTransformation1 columnar = new ColumnarTransformation1();
                return columnar.encrypt(plainText, key);
            }
            else
            {
                return "Invalid key or plaintext!";
            }
        }

        public string decryptColumnar(string plainText, string strKey)
        {
            if (key_validator(strKey, plainText.Count()))
            {
                int[] key = keyConverter(strKey);
                ColumnarTransformation1 columnar = new ColumnarTransformation1();
                return columnar.decrypt(plainText, key);
            }
            else
            {
                return "Invalid key or cipher!";
            }

        }
    }
}
