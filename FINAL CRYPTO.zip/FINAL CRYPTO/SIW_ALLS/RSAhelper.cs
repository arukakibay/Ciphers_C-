﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;


namespace SIW_ALLS
{
    class RSAhelper
    {
        private List<char> arr_en = new List<char>{ 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'
            , 'а', 'б', 'в', 'г', 'д', 'е', 'ё', 'ж', 'з', 'и', 'й', 'к', 'л', 'м', 'н', 'о', 'п', 'р', 'с', 'т', 'у', 'ф', 'х', 'ц', 'ч', 'ш', 'щ', 'ь', 'ы', 'ъ', 'э', 'ю', 'я' };

        private bool isSimple(int a)
        {
            for (int i = 2; i < a; i++)
            {
                if (a % i == 0)
                {
                    return false;
                }
            }

            return true;
        }
        private bool isSimple(int d, int check)
        {
            if (d > check)
            {
                for (int i = 2; i <= check; i++)
                {
                    if (d % i == 0 && check % i == 0)
                    {
                        return false;
                    }
                }
            }
            else
            {
                for (int i = 2; i <= d; i++)
                {
                    if (d % i == 0 && check % i == 0)
                    {
                        return false;
                    }
                }
            }
            return true;
        }

        public string generateKeyPair()//open
        {
            //Возьмем два больших простых числа p and q
            Random random = new Random();

            int p = random.Next() % 100 + 1;
            int q = random.Next() % 100 + 1;
            while (!isSimple(p))
            {
                p = random.Next() % 100 + 1;
            }
            while (!isSimple(q))
            {
                q = random.Next() % 100 + 1;
            }

            //Определим n, как результат умножения p on q (n= p*q).
            int n = p * q;

            //Выберем случайное число, которое назовем d. Это число должно быть взаимно простым (не иметь ни одного общего делителя, кроме 1) с результатом умножения (p-1)*(q-1).
            int d;
            int pq = (p - 1) * (q - 1);

            do
            {
                d = random.Next() % 100;
            } while (!isSimple(d, pq));

            //Определим такое число е, для которого является истинным следующее соотношение (e*d) mod ((p-1)*(q-1))=1.
            int e;
            for (int i = 1; ; i++)
            {
                if ((i * d) % (pq) == 1)
                {
                    e = i;
                    break;
                }
            }

            // Hазовем открытым ключем числа e и n, а секретным - d и n.
            string answer =e + ", " + n;
            return answer;
        }
        public string generateKeyPair1()//secret
        {
            //Возьмем два больших простых числа p and q
            Random random = new Random();

            int p = random.Next() % 100 + 1;
            int q = random.Next() % 100 + 1;
            while (!isSimple(p))
            {
                p = random.Next() % 100 + 1;
            }
            while (!isSimple(q))
            {
                q = random.Next() % 100 + 1;
            }

            //Определим n, как результат умножения p on q (n= p*q).
            int n = p * q;

            //Выберем случайное число, которое назовем d. Это число должно быть взаимно простым (не иметь ни одного общего делителя, кроме 1) с результатом умножения (p-1)*(q-1).
            int d;
            int pq = (p - 1) * (q - 1);

            do
            {
                d = random.Next() % 100;
            } while (!isSimple(d, pq));

            //Определим такое число е, для которого является истинным следующее соотношение (e*d) mod ((p-1)*(q-1))=1.
            int e;
            for (int i = 1; ; i++)
            {
                if ((i * d) % (pq) == 1)
                {
                    e = i;
                    break;
                }
            }

            // Hазовем открытым ключем числа e и n, а секретным - d и n.
            string answer =d + ", " + n;
            return answer;
        }


        public int[] encrypt(string text, int e, int n)
        {
            text = text.ToLower();
            //разбить шифруемый текст на блоки, каждый из которых может быть представлен в виде числа M(i)=0,1,2..., n-1( т.е. только до n-1).
            int[] blocks = new int[text.Length];
            for (int i = 0; i < text.Length; i++)
            {
                if (arr_en.Contains(text[i]))
                {
                    blocks[i] = arr_en.IndexOf(text[i]) + 1;
                }
                else
                {
                    blocks[i] = 100; // Для пробелов
                }
            }

            // зашифровать текст, рассматриваемый как последовательность чисел M(i) по формуле C(i) = (M(I) ^ e)mod n.
            BigInteger eB = BigInteger.Parse(e.ToString());
            BigInteger nB = BigInteger.Parse(n.ToString());
            for (int i = 0; i < blocks.Length; i++)
            {
                BigInteger a = BigInteger.Parse(blocks[i].ToString());

                blocks[i] = (int)BigInteger.ModPow(a, eB, nB);
            }

            return blocks;

        }

        public string decrypt(int[] cipher, int d, int n)
        {
            // Чтобы расшифровать эти данные, используя секретный ключ {d,n}, необходимо выполнить следующие вычисления: M(i) = (C(i)^d) mod n
            BigInteger dB = BigInteger.Parse(d.ToString());
            BigInteger nB = BigInteger.Parse(n.ToString());
            for (int i = 0; i < cipher.Length; i++)
            {
                BigInteger a = BigInteger.Parse(cipher[i].ToString());
                cipher[i] = (int)BigInteger.ModPow(a, dB, nB);
            }

            string answer = "";
            // В результате будет получено множество чисел M(i), которые представляют собой исходный текст.
            for (int i = 0; i < cipher.Length; i++)
            {
                if (cipher[i] > arr_en.Count)
                {
                    answer += " ";
                }
                else
                {
                    answer += arr_en[cipher[i] - 1];
                }
            }

            return answer;
        }
    }
}
