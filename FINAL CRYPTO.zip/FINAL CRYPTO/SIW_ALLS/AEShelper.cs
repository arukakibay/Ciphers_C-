﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SIW_ALLS
{
    class AEShelper
    {

        public string encrypt(string strKey, string plainText)
        {
            plainText = checkAndModifyPlainText(plainText);

            List<string[]> plainTextInHex = new List<string[]>();
            string[] hexes = new string[16];
            for (int i = 0; i < plainText.Length; i++) // Разбиваю текст на несколько линий по 16, если текст больше 16 символов 
            {
                hexes[i % 16] = Convert.ToString(plainText[i], 16);

                if ((i + 1) % 16 == 0)
                {
                    plainTextInHex.Add(hexes);
                    hexes = new string[16];
                }
            }

            AesKey key = new AesKey(strKey);

            string temporaryAnswer = key.getKeys();


            return temporaryAnswer;

        }

        private string checkAndModifyPlainText(string plainText)
        {
            int numberOfCharsToAdd = plainText.Length % 16;
            if (numberOfCharsToAdd == 0)
            {
                return plainText;
            }
            else
            {
                for (int i = 0; i < numberOfCharsToAdd; i++)
                {

                    plainText = plainText + " ";
                }
                return plainText;
            }
        }
    }
}
