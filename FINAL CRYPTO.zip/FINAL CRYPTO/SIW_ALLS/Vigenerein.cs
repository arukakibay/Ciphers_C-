﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SIW_ALLS
{
    interface Vigenerein
    {
        string encrypt(string plainText, string key);
        string decrypt(string plainText, string key);
        string analisys(string plainText, int wrong);
        bool checkAnswer(string answer);
        List<string> Crack(string ciphertext);
    }
}
