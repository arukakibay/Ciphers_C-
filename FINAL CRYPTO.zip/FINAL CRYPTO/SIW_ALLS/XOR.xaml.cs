﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SIW_ALLS
{
    /// <summary>
    /// Interaction logic for XOR.xaml
    /// </summary>
    public partial class XOR : Window
    {
        public XOR()
        {
            InitializeComponent();
        }
        XORin caesar = new XORR();
        private void Encrypt_Click(object sender, RoutedEventArgs e)
        {
            txt2.Text = caesar.xorIt(key.Text, txt1.Text);
            hextxt.Text = caesar.xorIt1(key.Text, txt1.Text);
        }

        private void Decrypt_Click(object sender, RoutedEventArgs e)
        { txt1.Text = caesar.Decrypt(txt2.Text, key.Text);
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            List<char> str = new List<char>();
            int i = 0;
            Random random = new Random();
            while (i < 2)
            {
                char c = (char)random.Next(97, 122);
                str.Add(c);
                i++;
            }
            key.Text = new string(str.ToArray());
        }
    }
}
