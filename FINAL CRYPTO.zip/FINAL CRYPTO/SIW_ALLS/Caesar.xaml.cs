﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SIW_ALLS
{
    /// <summary>
    /// Interaction logic for Caesar.xaml
    /// </summary>
    public partial class Caesar : Window
    {
        public Caesar()
        {
            InitializeComponent();
        }


        private void btn_e_Click(object sender, RoutedEventArgs e)
        {
            for (int n = 0; n < txt_e.Text.Length; n++)
                txt_d.Text += (char)(((((Convert.ToInt16(txt_e.Text.ToCharArray()[n]) - 97)) + Convert.ToInt16(key.Text)) % 26 + 97));

        }

        private void btn_d_Click(object sender, RoutedEventArgs e)
        {
            for (int n = 0; n < txt_e.Text.Length; n++)
                txt_d.Text += (char)(((((Convert.ToInt16(txt_e.Text.ToCharArray()[n]) - 97)) - Convert.ToInt16(key.Text)) % 26 + 97));

        }
    }
}
