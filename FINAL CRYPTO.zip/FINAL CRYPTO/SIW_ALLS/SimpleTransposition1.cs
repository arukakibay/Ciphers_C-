﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SIW_ALLS
{
    class SimpleTransposition1
    {
     

        public string encrypt(string text, int[] key)
        {
            int keyLength = key.Count();
            int tArraySize, count;
            char[] teil = new char[keyLength];
            char[] teil2 = new char[keyLength];
            List<char> cList = new List<char>();
            List<char> fList = new List<char>();

            // Key generation
          Console.WriteLine("\nYour key is: ");
           for (int i = 0; i < keyLength; i++) Console.Write("{0}", key[i]);

            // final sequence filling
           for (int i = 0; i < text.Count(); i++) if (text[i] != ' ') cList.Add(text[i]);
            if (cList.Count() % keyLength == 0) tArraySize = keyLength * (cList.Count() / keyLength);
            else tArraySize = keyLength * (cList.Count() / keyLength + 1);

            count = cList.Count();
            for (int i = 0; i < tArraySize - count; i++) cList.Add('X');

            // final sequence transposition
            for (int j = 0; j < cList.Count() / keyLength; j++)
            {
                for (int i = 0; i < keyLength; i++) teil[i] = cList[i + j * keyLength];
                for (int i = 0; i < keyLength; i++) teil2[key[i]] = teil[i];
                for (int i = 0; i < keyLength; i++) fList.Add(teil2[i]);
            }

            //Console.WriteLine("\nYour ciffer is:");
          for (int i = 0; i < fList.Count(); i++) Console.Write("{0}", fList[i]);
            StringBuilder sb = new StringBuilder();
            foreach (char symbol in fList)
            {
                sb.Append(symbol);
            }
            return sb.ToString();
        }
        private int fact(int a)
        {
            if (a <= 1) return 1;
            return fact(a - 1) * a;
        }

  

        public string decrypt(string text, int[] key)
        {
            int keyLength = key.Count();
            List<char> finalList = new List<char>();
            char[] teil = new char[keyLength];
            if (text.Length % key.Count() != 0)
            {
                int t = text.Length % key.Count();
                for (int i = 0; i < t; i++)
                {
                    text += "X";
                }
            }

            // decryption
            for (int j = 0; j < text.Count() / keyLength; j++)
            {
                for (int i = 0; i < keyLength; i++) teil[i] = text[i + j * keyLength];
                for (int i = 0; i < keyLength; i++) finalList.Add(teil[key[i]]);
            }
            try
            {

               // Console.WriteLine("\nDecrypted sequence is: ");
               // for (int i = 0; i < text.Count(); i++) Console.Write("{0}", finalList[i]);
                StringBuilder sb = new StringBuilder();
                foreach (char symbol in finalList)
                {
                    sb.Append(symbol);
                }
                return sb.ToString();
            }
            catch (Exception e)
            {
                throw new Exception();
            }
        }
    }
}
