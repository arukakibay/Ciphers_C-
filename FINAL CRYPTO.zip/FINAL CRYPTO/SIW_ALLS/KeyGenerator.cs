﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SIW_ALLS;

namespace SIW_ALLS
{
    class KeyGenerator
    {
        public string generateRSA()
        {
            RSAhelper rsa = new RSAhelper();
            return rsa.generateKeyPair();
        }
        public string generateRSA1()
        {
            RSAhelper rsa = new RSAhelper();
            return rsa.generateKeyPair1();
        }
        public string generateColumnar(int keyLength)
        {
           
            string str = "";
            int[] key = key_generator(keyLength + 2);
            for (int i = 0; i < key.Count() - 1; i++)
                str += key[i] + " ";
            str += key[key.Count() - 1];
            return str;
        }
        public int[] key_generator(int keyLength)
        {
            int[] key = new int[keyLength];
            for (int i = 0; i < keyLength; i++) key[i] = i;
            Random r = new Random();
            for (int i = key.Length; i > 0; i--)
            {
                int j = r.Next(i); //4
                int k = key[j];
                key[j] = key[i - 1];
                key[i - 1] = k;
            }
            return key;
        }
    }
}
