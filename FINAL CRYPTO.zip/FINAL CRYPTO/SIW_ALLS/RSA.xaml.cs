﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SIW_ALLS
{
    /// <summary>
    /// Interaction logic for RSA.xaml
    /// </summary>
    public partial class RSA : Window
    {
        Encryptor encryptor = new Encryptor();
        KeyGenerator generator = new KeyGenerator();

        public RSA()
        {
            InitializeComponent();
        }

        private void btnencrypt_Click(object sender, RoutedEventArgs e)
        {
            Output.Text = encryptor.encryptRSA(Input.Text, PublicKey.Text);
        }

        private void Generate_Key_Click(object sender, RoutedEventArgs e)
        {
           PublicKey.Text = generator.generateRSA();
           PrivatKey.Text = generator.generateRSA1();
        }

        private void Decrypt_Click(object sender, RoutedEventArgs e)
        {
            Output.Text = encryptor.decryptRSA(Input.Text, PrivatKey.Text);
        }
    }
}
