﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SIW_ALLS;
using System.Security.Cryptography;
using System.ComponentModel;
using System.Data;
using System.Drawing;

namespace SIW_ALLS
{
    /// <summary>
    /// Interaction logic for AES.xaml
    /// </summary>
    public partial class AES : Window
    {
        Encryptor encryptor = new Encryptor();
        private byte[] IV = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16 };
        private int BlockSize = 128;
        public AES()
        {
            InitializeComponent();
        }

        private void show_btn_Click(object sender, RoutedEventArgs e)
        {
            OutputKey.Text = encryptor.encryptAES(Input.Text, KeyField.Text);
        }

        private void encbtn_Click(object sender, RoutedEventArgs e)
        {
            // Output.Text = encryptor.encryptAES(Input.Text, KeyField.Text);
            if (KeyField.Text == "") return;
            //  string[] hexes = new string[16];
            // hexes[i % 16] = Convert.ToString(plainText[i], 16);
            byte[] bytes = Encoding.Unicode.GetBytes(Input.Text);
            //Convert.ToString(plainText[i], 16);
            //Encrypt
            SymmetricAlgorithm crypt = Aes.Create();
            HashAlgorithm hash = MD5.Create();
            crypt.BlockSize = BlockSize;
            crypt.Key = hash.ComputeHash(Encoding.Unicode.GetBytes(KeyField.Text));
            crypt.IV = IV;

            using (MemoryStream memoryStream = new MemoryStream())
            {
                using (CryptoStream cryptoStream = new CryptoStream(memoryStream, crypt.CreateEncryptor(), CryptoStreamMode.Write))
                {
                    cryptoStream.Write(bytes, 0, bytes.Length);
                }

                Output.Text = Convert.ToBase64String(memoryStream.ToArray());
            }

        }

        private void decbtn_Click(object sender, RoutedEventArgs e)
        {
            if (KeyField.Text == "") return;
            //Decrypt
            byte[] bytes = Convert.FromBase64String(Input.Text);
            SymmetricAlgorithm crypt = Aes.Create();
            HashAlgorithm hash = MD5.Create();
            crypt.Key = hash.ComputeHash(Encoding.Unicode.GetBytes(KeyField.Text));
            crypt.IV = IV;

            using (MemoryStream memoryStream = new MemoryStream(bytes))
            {
                using (CryptoStream cryptoStream = new CryptoStream(memoryStream, crypt.CreateDecryptor(), CryptoStreamMode.Read))
                {
                    byte[] decryptedBytes = new byte[bytes.Length];
                    cryptoStream.Read(decryptedBytes, 0, decryptedBytes.Length);
                    Output.Text = Encoding.Unicode.GetString(decryptedBytes);
                }
            }
        }
    }
}
