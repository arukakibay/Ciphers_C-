﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SIW_ALLS
{
    /// <summary>
    /// Interaction logic for Vigenere.xaml
    /// </summary>
    public partial class Vigenere : Window
    {
        public Vigenere()
        {
            InitializeComponent();
        }

        Vigenerein caesar = new VigenereF();
        private int wrong = 0;
        private void Go_Click(object sender, RoutedEventArgs e)
        {
            if ((bool)Encrypt.IsChecked)
            {
                Output.Text = caesar.encrypt(Input.Text, Key.Text);
            }
            else
            {
                string result;
                string key = Key.Text;
                string keyl = keylist.Text;
                do
                {

                    if (Key.Text == "")
                    {
                        key = caesar.analisys(Input.Text, wrong);
                        wrong++;
                    }
                    List<string> keys = caesar.Crack(Input.Text);
                    //keylist.Text = keys[0];
                    //keylist.Text = keys[1];
                    //keylist.Text = keys[2];
                    //  keylist.Text = keys[3];
                    for (int i = 0; i < keys.Count; i++)
                    {
                        keylist.Text = keys[i];
                    }
                    result = caesar.decrypt(Input.Text, keylist.Text);

                    //  keylist.Text = keys[3];
                } while (!caesar.checkAnswer(result));
                Output.Text = result;
                Key.Text = key;

            }
        }

        private void Clean_Click(object sender, RoutedEventArgs e)
        {
            Output.Text = "";
            Input.Text = "";
        }

        private void ChangeLanguage(object sender, SelectionChangedEventArgs e)
        {
            if (comboBox.SelectedIndex == 0)
            {
                caesar = new VigenereF();
            }
        }

        private void Wrong(object sender, TextChangedEventArgs e)
        {
            wrong = 0;
        }

        private void Encrypt_Checked(object sender, RoutedEventArgs e)
        {

        }
    }
}
