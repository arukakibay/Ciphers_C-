﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SIW_ALLS
{
    class AesKey
    {
        public static string[,] Sbox =
{{"63" ,"7c" ,"77" ,"7b" ,"f2" ,"6b" ,"6f" ,"c5" ,"30" ,"01" ,"67" ,"2b" ,"fe" ,"d7" ,"ab" ,"76"},
 { "ca" ,"82" ,"c9" ,"7d" ,"fa" ,"59" ,"47" ,"f0" ,"ad" ,"d4" ,"a2" ,"af" ,"9c" ,"a4" ,"72" ,"c0"},
 { "b7" ,"fd" ,"93" ,"26" ,"36" ,"3f" ,"f7" ,"cc" ,"34" ,"a5" ,"e5" ,"f1" ,"71" ,"d8" ,"31" ,"15" },
 { "04" ,"c7" ,"23" ,"c3" ,"18" ,"96" ,"05" ,"9a" ,"07" ,"12" ,"80" ,"e2" ,"eb" ,"27" ,"b2" ,"75" },
 { "09" ,"83" ,"2c" ,"1a" ,"1b" ,"6e" ,"5a" ,"a0" ,"52" ,"3b" ,"d6" ,"b3" ,"29" ,"e3" ,"2f" ,"84" },
 { "53" ,"d1" ,"00" ,"ed" ,"20" ,"fc" ,"b1" ,"5b" ,"6a" ,"cb" ,"be" ,"39" ,"4a" ,"4c" ,"58" ,"cf"},
 { "d0" ,"ef" ,"aa" ,"fb" ,"43" ,"4d" ,"33" ,"85" ,"45" ,"f9" ,"02" ,"7f" ,"50" ,"3c" ,"9f" ,"a8" },
 { "51" ,"a3" ,"40" ,"8f" ,"92" ,"9d" ,"38" ,"f5" ,"bc" ,"b6" ,"da" ,"21" ,"10" ,"ff" ,"f3" ,"d2" },
 { "cd" ,"0c" ,"13" ,"ec" ,"5f" ,"97" ,"44" ,"17" ,"c4" ,"a7" ,"7e" ,"3d" ,"64" ,"5d" ,"19" ,"73" },
 { "60" ,"81" ,"4f" ,"dc" ,"22" ,"2a" ,"90" ,"88" ,"46" ,"ee" ,"b8" ,"14" ,"de" ,"5e" ,"0b" ,"db" },
 { "e0" ,"32" ,"3a" ,"0a" ,"49" ,"06" ,"24" ,"5c" ,"c2" ,"d3" ,"ac" ,"62" ,"91" ,"95" ,"e4" ,"79" },
 { "e7" ,"c8" ,"37" ,"6d" ,"8d" ,"d5" ,"4e" ,"a9" ,"6c" ,"56" ,"f4" ,"ea" ,"65" ,"7a" ,"ae" ,"08" },
 { "ba" ,"78" ,"25" ,"2e" ,"1c" ,"a6" ,"b4" ,"c6" ,"e8" ,"dd" ,"74" ,"1f" ,"4b" ,"bd" ,"8b" ,"8a" },
 { "70" ,"3e" ,"b5" ,"66" ,"48" ,"03" ,"f6" ,"0e" ,"61" ,"35" ,"57" ,"b9" ,"86" ,"c1" ,"1d" ,"9e" },
 { "e1" ,"f8" ,"98" ,"11" ,"69" ,"d9" ,"8e" ,"94" ,"9b" ,"1e" ,"87" ,"e9" ,"ce" ,"55" ,"28" ,"df" },
 { "8c" ,"a1" ,"89" ,"0d" ,"bf" ,"e6" ,"42" ,"68" ,"41" ,"99" ,"2d" ,"0f" ,"b0" ,"54" ,"bb" ,"16" } };

        AesRoundKey[] key = new AesRoundKey[11];

        public AesKey(string strKey)
        {
            // Console.WriteLine("KEY");
            key[0] = new AesRoundKey(strKey);
            //key[0].print();

            for (int i = 1; i <= 10; i++)
            {
                key[i] = key[i - 1].addRoundKey(i);
                //  key[i].print();
            }
        }

        public string getKeys()
        {
            string keysToPresent = "";
            int i = 0;
            foreach (AesRoundKey roundKey in key)
            {
                keysToPresent += "Round Key-" + i++ + ": ";
                foreach (string[] list in roundKey.keys)
                {
                    foreach (string str in list)
                    {
                        keysToPresent += str + " ";
                    }
                }
                keysToPresent += Environment.NewLine;
            }
            return keysToPresent;
        }

    }

    public class AesRoundKey
    {
        private string[] roundConstants = { "01", "02", "04", "08", "10", "20", "40", "80", "1B", "36" };

        public List<string[]> keys = new List<string[]>();

        public AesRoundKey(string strKey)
        {
            int counter = 0;
            for (int i = 0; i < 4; i++)
            {
                keys.Add(new string[4]);
                for (int j = 0; j < 4; j++)
                {
                    keys[i][j] = Convert.ToString(strKey[counter++], 16);
                }
            }
        }

        AesRoundKey(List<string[]> keys)
        {
            this.keys = keys;
        }

        public AesRoundKey addRoundKey(int order)
        {
            List<string[]> newKey = new List<string[]>();

            newKey.Add(bitwiseHexOr(g(keys[3], order), keys[0]));
            newKey.Add(bitwiseHexOr(newKey[0], keys[1]));
            newKey.Add(bitwiseHexOr(newKey[1], keys[2]));
            newKey.Add(bitwiseHexOr(newKey[2], keys[3]));

            return new AesRoundKey(newKey);
        }

        private string[] bitwiseHexOr(string[] a, string[] b)
        {
            string[] newBytes = new string[4];
            for (int i = 0; i < 4; i++)
            {
                newBytes[i] = Convert.ToString(
                    Convert.ToInt32(a[i], 16) ^ Convert.ToInt32(b[i], 16)
                    , 16);
            }

            return newBytes;
        }

        private string[] circularByteLeftShift(string[] bytes)
        {
            string[] newBytes = new string[4];
            for (int i = 3; i >= 0; i--)
            {
                newBytes[i] = bytes[(i + 1) % 4];
            }
            return newBytes;
        }

        private string[] byteSubstitution(string[] bytes)
        {
            string[] newBytes = new string[4];
            int counter = 0;
            foreach (string bit in bytes)
            {
                string a = Convert.ToString(bit.Length == 2 ? bit[0] : '0');
                int firstIndex = Convert.ToInt32(a, 16);
                string b = Convert.ToString(bit.Length == 2 ? bit[1] : bit[0]);
                int secondIndex = Convert.ToInt32(b, 16);
                newBytes[counter++] = AesKey.Sbox[firstIndex, secondIndex];
            }

            return newBytes;
        }

        private string[] addingRoundConstant(string[] bytes, int order)
        {
            string[] newBytes = bytes;
            newBytes[0] = Convert.ToString(Convert.ToInt32(newBytes[0], 16) ^ Convert.ToInt32(roundConstants[order - 1], 16), 16);


            return newBytes;
        }

        private string[] g(string[] key, int order)
        {
            return addingRoundConstant(byteSubstitution(circularByteLeftShift(key)), order);
        }

        /*  public void print()
          {

              Console.WriteLine("---------------");
              foreach (string[] four in keys)
              {
                  foreach (string bit in four)
                  {
                      Console.Write(bit + " ");
                  }
              }
              Console.WriteLine();
              Console.WriteLine("---------------");
          }*/

    }
}
