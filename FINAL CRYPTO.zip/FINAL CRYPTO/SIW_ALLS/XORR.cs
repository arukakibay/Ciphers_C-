﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SIW_ALLS
{
    class XORR : XORin
    {

        private string GetRepeatKey(string s, int n)
        {
            var r = s;
            while (r.Length < n)
            {
                r += r;
            }

            return r.Substring(0, n);
        }

        public string xorIt(string key, string input)///////////////
        {
            var currentKey = GetRepeatKey(key, input.Length);
            var res = string.Empty;
            for (var i = 0; i < input.Length; i++)
            {
                res += ((char)(input[i] ^ currentKey[i])).ToString();
            }

            return res;

        }
        public string xorIt1(string key, string input)
        {

            string sbOut1 = String.Empty;
            for (int i = 0; i < input.Length; i++)
            {
                sbOut1 += String.Format("{0:00}", input[i] ^ key[i % key.Length]);
            }
            //long dec2 = Convert.ToInt64(sbOut, 16);

            return sbOut1.ToString();
        }
        public string Decrypt(string cipher, string key) {
     
            int length = cipher.Count();

            char[] keySequence2 = new char[length];
            for (int i = 0; i < length; i++)
                keySequence2[i] = key[i % key.Count()];

            //
            byte[] bytes2 = new byte[length];

            for (int i = 0; i < length; i++)
                bytes2[i] = (byte)(Convert.ToByte(cipher[i]) ^ keySequence2[i]);

            string result2 = System.Text.Encoding.UTF8.GetString(bytes2);

            return result2;
        }
    }
}
