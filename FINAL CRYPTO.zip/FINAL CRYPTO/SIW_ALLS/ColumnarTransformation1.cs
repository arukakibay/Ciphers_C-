﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SIW_ALLS
{
    class ColumnarTransformation1
    {
        public int[] key_generator(int keyLength)
        {
            int[] key = new int[keyLength];
            for (int i = 0; i < keyLength; i++) key[i] = i;
            Random r = new Random();
            for (int i = key.Length; i > 0; i--)
            {
                int j = r.Next(i); //4
                int k = key[j];
                key[j] = key[i - 1];
                key[i - 1] = k;
            }
            return key;
        }

        public void matrixDisplayer(char[] sequence, int[] key)
        {

            for (int i = 0; i < key.Count(); i++)
            {
                Console.Write("{0} ", key[i]);
            }
            Console.Write("\n");
            for (int i = 0; i < sequence.Count() / key.Count(); i++)
            {
                for (int j = 0; j < key.Count(); j++)
                {
                    Console.Write("{0} ", sequence[i * key.Count() + j]);
                }
                Console.Write("\n");
            }
            Console.Write("\n");
        }

  

        

        public string encrypt(string plainText, int[] key)
        {
            int textLength = plainText.Count();
            int keyLength = key.Length;
            // generating key
            // int[] key = key_generator(keyLength);
           // keyPrinter(key);

            // removing spaces
            for (int i = 0; i < textLength; i++)
            {
                if (plainText[i] == ' ')
                {
                    plainText = plainText.Remove(i, 1);
                    textLength = plainText.Count();
                    i--;
                }
            }

            int arrayLength = textLength;
            if (textLength % keyLength != 0)
                arrayLength += keyLength - textLength % keyLength;

            char[] firstArray = new char[arrayLength];
            char[] finalArray = new char[arrayLength];

            for (int i = 0; i < textLength; i++)
                firstArray[i] = plainText[i];
            for (int i = textLength; i < arrayLength; i++)
                firstArray[i] = '-';

            matrixDisplayer(firstArray, key);

            int columnHeight = arrayLength / keyLength;

            for (int i = 0; i < keyLength; i++)
            {
                for (int j = 0; j < columnHeight; j++)
                {
                    finalArray[i * columnHeight + j] = firstArray[keyLength * j + Array.IndexOf(key, i)];
                }
            }

            return new string(finalArray);
        }

        public string decrypt(string Ciffer, int[] key)
        {
            int keyLength = key.Count();
            int textLength = Ciffer.Count();
            char[] finalArray = new char[textLength];

            int columnHeight = textLength / keyLength;

            for (int i = 0; i < keyLength; i++)
            {
                for (int j = 0; j < columnHeight; j++)
                {
                    finalArray[Array.IndexOf(key, i) + j * keyLength] = Ciffer[columnHeight * i + j];
                }
            }

            string finalString = "";
            for (int i = 0; i < textLength; i++)
                finalString += finalArray[i];

            for (int i = 0; i < textLength; i++)
                if (finalString[i] == '-')
                {
                    finalString = finalString.Remove(i, 1);
                    textLength = finalString.Count();
                    i--;
                }
            return finalString;
        }
    }
}
